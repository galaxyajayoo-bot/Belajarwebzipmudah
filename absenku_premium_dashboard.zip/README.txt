
ABSENKU PREMIUM DASHBOARD

FITUR:
- Dashboard premium modern
- Grafik kehadiran Chart.js
- Responsive mobile & desktop
- Statistik realtime
- UI gaming / sekolah modern
- Siap upload ke domain
- Cocok untuk sekolah

CARA UPLOAD:
1. Extract ZIP
2. Upload semua file ke hosting/domain
3. Buka index.html

SUPPORT:
- Netlify
- Vercel
- cPanel
- Hosting sekolah
